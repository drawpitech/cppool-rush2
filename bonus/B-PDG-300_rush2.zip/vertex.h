/*
** EPITECH PROJECT, 2021
** Paradigms Seminar
** File description:
** Exercice 02
*/

#pragma once

#include "object.h"

extern const Class  *Vertex;

